module.exports = {
	title: 'Alexander Brunt Media Assignment Submission',
	description: 'Trying something a bit different. May differention save me!',
	themeConfig: {
		nav: [
			{ text: 'Home', link: '/' },
			{ text: 'Unit Plan', link: '/counter/assignment.html' }
		],
		sidebar: [
			{
				title: 'Unit Plan',
				collapsable: false,
				link: '/counter/assignment.html',
				children: [
					['/counter/assignment', 'Overview'],
					['/counter/TS', 'AITSL Standards Addressed'],
					['/counter/FR', 'Feedback and Reflection'],
				]
			},
		]
	},
	// Extend Webpack configuration
	chainWebpack: (config, isServer) => {
		// Conditionally apply transformations for client-side code only
		if (!isServer) {
			// Example: Adding a rule for image optimization
			config.module
			.rule('images')
			.test(/\.(png|jpe?g|gif|svg)(\?.*)?$/)
			.use('url-loader')
			.loader('url-loader')
			.options({
				limit: 10000, // Limit for inline images in bytes
			name: 'assets/img/[name].[hash:8].[ext]' // Naming pattern for image files
			});
		}
	}
};
