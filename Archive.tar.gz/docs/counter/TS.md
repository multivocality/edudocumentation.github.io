
### AITSL Standards Addressed

- **Content and teaching strategies:** The unit covers key concepts and structures of media studies, focusing on multimedia texts and their production (KU1, KU2).
- **Content selection and organisation:** The content is organised logically, building on previous knowledge and skills (P1, P2).
- **Curriculum, assessment, and reporting:** The unit is designed based on the relevant curriculum, with clear assessment criteria and performance standards (RA1, RA2, RA3, C1, C2).
- **Literacy and numeracy:** The unit incorporates literacy skills through analysing and creating multimedia texts and numeracy skills through planning and executing production tasks (P1, P2).
- **ICT:** The unit heavily relies on the use of ICT for multimedia production and provides opportunities for students to expand their ICT skills (P2).
- **Differentiation:** The unit offers differentiation strategies to cater to diverse learning needs and abilities (KU1, KU2, P1, P2).
- **Teaching strategies:** The unit employs various teaching strategies, including group work, discussions, and hands-on production tasks (P1, P2, C1, C2).
- **Resources:** The unit utilises a range of resources, including examples of multimedia texts, production software and hardware, and online resources (KU1, KU2, P2).
- **Communication:** The unit encourages various forms of communication, including discussions, presentations, and media terminology (C1, C2).
- **Evaluation and improvement:** The unit incorporates ongoing formative assessment and self-reflection to evaluate and improve teaching and learning (RA3).
