---
title: Assessment Task 1 (Part B)
---

Hey, this is a bug, please use navigation bar on the lefthand side to wayfind.
