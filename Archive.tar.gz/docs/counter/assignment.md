---
title: Assessment Task 1 (Part B)
---

# Unit Plan:
> Exploring Digital Texts in Media Studies


&nbsp;
## Overview
- **Year Level:** 11
- **Subject:** Media Studies
- **Duration:** 2 x 90-minute sessions per week for five weeks

&nbsp;
### **School Context:**

*Norwood International High School* is a progressive, co-educational government school catering for approximately 1620 Year 7-12 students from diverse cultural and linguistic backgrounds. The school is located in the foothills of eastern Adelaide. The school community is committed to providing an engaging, internationalised curriculum that develops students academically, socially and emotionally to become active, global citizens and life-long learners. This commitment is reflected in its guiding statements, international curriculum (IB Middle Years and Diploma programs, extensive Languages program and cross-cultural collaborations), large international student program and its engagement in the rigorous Council of International Schools accreditation framework. ([NIHS Context Statement ](https://nihs.sa.edu.au/wp-content/uploads/2023/12/2023-NIHS-School-Context-Statement.pdf))



&nbsp;
### **Class Context:**
The class is a reflection of the broader school context. As such, we can expect a great diversity of tallent. To ilicit the best performance from learners, we must address the learning needs of the following students:
- **Abi** has been diagnosed with dyslexia and benefits from tailored reading materials and assistive technologies to enhance her learning experience.
- Both **Bradley** and **Carman** display signs of Attention Deficit Hyperactivity Disorder (ADHD) and require tasks which are targeted towards rapid information processing in short procession. May need assistance in directing attention.
- **Delaney** requires differentiated learning tasks which are are designed to facilitate their academic growth, can process symbols and content aimed at year 3 standards.
- **Eric** is an Aboriginal and Torres Strait Islander (ATSI) student who loves to share his cultural background. The entire class enjoys this. he benefits from culturally responsive pedagogy and the support of a School Support Officer (SSO).

&nbsp;
## Introducing Chomsky to TikTok.
As per the [2024 SACE Media Studies Subject Outline](https://www.sace.sa.edu.au/documents/652891/5008045/Media+Studies+Subject+Outline+%28for+teaching+in+2024%29.docx/511cdc13-1b9f-0b95-ee6e-99e41540d6c1?version=1.1), this Stage 1 unit has been constructed to ''develop students’ understanding of how meaning is created and communicated to others in local and global communities''.

In this unit, Year 11 students will engage in an immersive exploration of media's omnipresence in society and its influence on perception and identity. This unit will see students critically observe media texts, question industry practices and analyse media texts in order to cultivate a sensitivity to trends shaping content and consumption patterns in the digital age. Students will craft narratives that portray their point of view, informed by their learning. Through this lens we consider the media's profound impact on framing world events, interpreting cultural phenomena, and entertaining diverse audiences - on a global scale. Introducing Chomsky to TikTok.

In this context, Media Studies emerges as an investigative and creative platform where Australian and global media landscapes are studied and experienced through active student involvement. Here, students will dissect and discuss the dynamic interactions between media and audiences, create content reflecting their understanding, and navigate the intricate dance of influence and identity formation. This endeavour aims to empower students to become discerning consumers and innovative creators within the media sphere, fostering a critical awareness that is indispensable post-digital revolution.

The unit is framed around essential questions that drive a deep inquiry into the function and form of media in society. These questions guide the learning journey, prompting students to critically evaluate their engagement with media and its role in shaping their views, choices, and leisure time. Through a blend of theoretical analysis and practical application, the unit prepares students for the challenges and opportunities that lie ahead, be it in further academic pursuits or diverse career pathways within the ever-evolving media industry.

&nbsp;
## Essential Questions
Think about the last time you watched a video online or scrolled your feed.
How did it make you feel, think, or see the world? Was this empowering or deflating?
Before we delve into the bottomless ocean of digital media, should we consider saftey measures?
Consider how what we ingest shapes the perception of reality. What techniques do creators use to influence our thoughts, feelings, and decisions?

&nbsp;
## Unit Objectives
By the end of this unit, students will be able to:
1. Understand the impact of digital technology and high-speed data transfer on media production and consumption (KU1, KU2).
2. Analyse and evaluate established and emerging multimedia technology conventions (RA1, RA2).
3. Reflect on their own experiences and interactions with multimedia texts (RA3).
4. work together to plan, create, and evaluate a multimedia text which considers audience, purpose, and ethical issues (P1, P2, C1, C2).


&nbsp;
## Learning Requirements
[(SACE Subject Outline, p.6)](https://www.sace.sa.edu.au/web/media-studies/stage-1/planning-to-teach/subject-outline)
1.	demonstrate understanding of the ways in which societies are represented by media
2.	research and analyse the form, content, context, and intended audiences of media texts
3.	creatively use media technologies in individual and collaborative production activities
4.	explore aspects of the dynamics of the media industry
5.	analyse their interactions with media.

&nbsp;
## Weekly Breakdown

&nbsp;
### Week 1
| Lesson 1 | Lesson 2 |
| ----------- | ----------- |
| Introduction to the unit and its objectives.  | Analyse the conventions of various multimedia technologies (RA1). |
| Discuss the concept of media convergence and its impact on media texts (KU1). | Discuss the advantages and disadvantages of established and emerging technologies (RA2). |
| Explore examples of multimedia texts and their features (KU2). | Groups brainstorm ideas for their multimedia production task (P1). |
| Introduce the multimedia production task and form groups. |

&nbsp;
### Week 2
| Lesson 1 | Lesson 2 |
| ----------- | ----------- |
 | Discuss the importance of considering audience and purpose when creating multimedia texts (KU2). | Explore the legal and ethical issues surrounding multimedia production (KU1). |
 | Groups develop a plan for their multimedia production, including techniques to be used (P1). | Groups finalise their production plans, incorporating legal and ethical considerations (P1). |
 | Teacher provides feedback on plans and guides students in refining their ideas. | Begin working on multimedia production using appropriate technologies (P2). |

&nbsp;
### Week 3
| Lesson 1 | Lesson 2 |
| ----------- | ----------- |
| Continue working on multimedia production (P2). | Explore how different audiences interpret multimedia texts differently (KU2). |
| Teacher provides ongoing support and feedback to groups. | Groups continue working on their multimedia production (P2). |
| Discuss strategies for effective collaboration and problem-solving (C2). | Teacher facilitates peer feedback sessions for groups to share progress and receive constructive criticism. |

&nbsp;
### Week 4
| Lesson 1 | Lesson 2 |
| ----------- | ----------- |
| Groups finalise their multimedia productions (P2). | Groups present their final multimedia products to the class (C1, C2). |
| Prepare for presentations and evaluations of final products. | Engage in class discussions and provide feedback on each group's work. |
| Discuss the importance of post-production work in multimedia texts (C1). | Students individually evaluate their contributions to the group production (RA3). |

&nbsp;
### Week 5
| Lesson 1 | Lesson 2 |
| ----------- | ----------- |
| Reflect on personal experiences and interactions with multimedia texts (RA3). | Conclude the unit with a summary of key learning points. |
| Discuss the impact of multimedia texts on individual and group identity (KU1). | Students complete a self-reflection on their learning throughout the unit (RA3). |
| Explore career opportunities in the media industry related to multimedia production (C2). | Discuss the importance of media literacy in an increasingly digital world (KU1, KU2). |

&nbsp;
## Differentiation Plan
### In action
- Provide additional support and resources for students who need extra guidance.
- Offer extension activities for students who demonstrate mastery of the content.
- Allow different roles within group work to cater to individual strengths and interests.
- Ensure materials and tasks are accessible to students with dyslexia through the use of dyslexia-friendly fonts and backgrounds.
- Incorporate breaks and flexible timelines for students with ADHD to manage focus and engagement.
- Provide scaffolding and additional support for students with delayed learning capabilities.
- Integrate culturally responsive materials and activities.

### Instruction
- Utilise visual aids (infographics, videos) and auditory materials (podcasts, audio recordings).
- Provide structured and flexible learning spaces with clear instructions and flexible seating.
- Implement assistive technology, including text-to-speech software and organisation apps.

### Assessment
- Use formative assessment for regular, constructive feedback.
- Offer varied summative assessment methods: digital portfolios, video essays, oral presentations, as well as negotiated terms.
- Provide assessment choices in topics for projects or presentations.

### Engagement
- Facilitate peer support and group work with mixed ability grouping.
- Set personalised learning goals with each student, considering their needs and aspirations.
- Involve the School Support Officer (SSO) in planning and supporting Eric.

&nbsp;
## Assessment

### **Formative assessment**
During the teaching and learning program the teacher provides feedback to students in a perpetual cycle. Students assess peers and provide feedback. While individually, students engage in reflective activities to clarify purpose, in relation to performance standards.

### **Summative assessment**
The summative assessment for this unit comprises three components designed to assess students' mastery of multimedia production, their ability to evaluate multimedia texts critically, and their reflective capacity regarding their learning journey and the ethical considerations of multimedia production.

> #### 1. Group Multimedia Production Task

**Constraints:**

1. 5-minute multimedia production
2. Requires two pieces of evidence Plan (For feedback) and Final Submission.

**Objective:**
    Synthesize knowledge and skills in multimedia production to create coherent media text that is mindful of audience needs, employs medium-specific conventions effectively, and navigates legal and ethical considerations.

**Process:**
    In groups, students brainstorm, plan, and develop a multimedia production, encapsulating the planning phase (a and b) and creating a final media product (c).
    This task will be guided by the questions outlined, requiring students to articulate their production's core message, audience considerations, and the utilization of medium conventions.
    Additionally, groups must demonstrate an understanding of how diverse audiences may interpret their text and detail how they have navigated legal and ethical landscapes in their production.

> #### 2. Individual Evaluation of the Final Media Product

**Constraints:**

1. Presentation or essay
2. 300 word equivalent.

**Objective:**
    To cultivate analytical skills through the evaluation of the group’s final media product, focusing on its effectiveness, the integration of multimedia conventions, and the handling of ethical considerations.

**Process:**
    Students will individually deliver a 300-word oral presentation or compose an essay to evaluate the group’s final media product.
    This evaluation will demand critical engagement with the production process, alignment of the final product with its intended message and audience, and an assessment of ethical considerations.

> #### 3. Individual Self-Reflection on Learning

**Constraints:**

1. Written
2. 300 words.

**Objective:**
    To encourage introspection regarding personal learning experiences, group task contributions, and multimedia texts' broader implications on individual and societal levels.

**Process:**
    Students will complete a self-reflection exercise, considering their personal growth throughout the unit, their role and contributions to the group project, and their insights on the impact of multimedia texts on identity and media literacy.

---
### Student Task sheet Example

**Activities**

In small groups, produce a 5-minute multimedia production

    A. Identify relevant techniques to be used
    B. Develop a plan for your production
    C. Deliver a media product

Then individually script

    300-word oral presentation or essay which evaluates your media product

Questions for consideration:

- What is the core message or information that your text seeks to convey?
- How have you considered your intended audience's needs when selecting the medium for your text?
- In what ways have you utilized the conventions of your chosen medium to craft your text effectively?
- What factors might lead diverse audiences to interpret your text differently?
- How have you addressed legal and ethical considerations when creating your text?

---

### Rubric Basis
**Producing**
- P1	Design and planning of media texts.
- P2	Use of appropriate production techniques and technologies.

**Communication**
- C1	Reproduction of the forms and features of media texts to convey meaning.
- C2	Fluency of expression and use of appropriate media terminology.


&nbsp;
## Resources
### In-Class
 This course requires the use of multimedia production software and hardware, ICT Lab or School laptops.

### Examples of multimedia texts from various sources, found within Lesson Plans

- **eSafety Comissioner** - [https://www.esafety.gov.au/](https://www.esafety.gov.au/)

  - Australian Government online safety measures

- **Common Sense Education** - [https://www.commonsense.org/education/](https://www.commonsense.org/education/)

  - Digital citizenship and literacy resources, including reviews of digital tools and age-appropriate media to use in the classroom.

- **TED-Ed** - [https://ed.ted.com/](https://ed.ted.com/)

  - Educational videos on a wide range of topics, including media studies.

- **Khan Academy** - [https://www.khanacademy.org/](https://www.khanacademy.org/)

  - Interactive approaches beneficial for students requiring differentiation.

- **Edpuzzle** - [https://edpuzzle.com/](https://edpuzzle.com/)

  - Embed questions within videos, ensuring active student engagement.

- **Vimeo** - [https://vimeo.com/](https://vimeo.com/)

  - Hosts a number of high-quality documentaries and short films.

- **PBS LearningMedia** - [https://www.pbslearningmedia.org/](https://www.pbslearningmedia.org/)

  - Videos on media literacy and digital storytelling.

- **The Literacy Shed** - [https://www.literacyshed.com/](https://www.literacyshed.com/)

  - Film and animation, aimed at improving students' comprehension and creative writing skills.

- **Adobe Education Exchange** - [https://edex.adobe.com/](https://edex.adobe.com/)

  - Digital multimedia elements.


### Useful Websites for Australia's Media Industry employment bodies

- **Screen Australia** - [https://www.screenaustralia.gov.au/](https://www.screenaustralia.gov.au/)

  - Funding and resources for Australian film, television, documentary, and digital media projects.

- **ArtsHub Australia** - [https://www.artshub.com.au/](https://www.artshub.com.au/)

  - Specializes in arts, media, and entertainment job listings across Australia.

- **Creative Spirits** - [https://www.creativespirits.info/](https://www.creativespirits.info/)

  - Job opportunities related to Aboriginal media, arts, and culture in Australia.

- **Pedestrian Jobs** - [https://www.pedestrian.tv/jobs/](https://www.pedestrian.tv/jobs/)

  - For niche or unique roles in the Australias media, entertainment, and creative industries.

- **The Loop** - [https://www.theloop.com.au/](https://www.theloop.com.au/)

  - Job listings, portfolio hosting, and networking opportunities in various media sectors.
