
#### Feedback and Reflection

> Curriculum links with SACE?

Yes, can copy.

> Referencing documents within unit plan (best practices for differentiation)

No not required.

> Should the document contain text targeted at students? (See Essential Q's)

Ideally it should be targeted at people reading the lesson plan (IE site leaders) --> Implemented anyway to use later.

> Unit template non applicable sections: Placeholder substitutions?

Yes this is fine.

> Listing AITSL Standards within template for assessment:

Can I list these at the bottom of the document.

> How many words/detail?

What you already have is fine.
