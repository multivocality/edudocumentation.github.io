---
home: true
actionText: View Assignment Submission
actionLink: /counter/assignment.html
features:
- title: Contemporary Publishing Method
  details: Assignment delivery for Assessment Task 1 (Part B) as part of The University of Adelaide course on Curriculum and Pedagogy 2024 Media and Digital Technologies.
- title: By Alexander Brunt
  details: a1809039
---
